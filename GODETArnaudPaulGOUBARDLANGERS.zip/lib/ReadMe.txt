La librairie Jansi, disponible ici : https://github.com/fusesource/jansi
est necessaire pour pouvoir voir les couleurs dans la console pour Gobblet-Gobblers.

Attention !!! Si vous utilisez Eclipse veuillez installer ce plug-in
 pour pouvoir interpreter les codes Ansi comme des couleurs dans la console :
http://mihai-nita.net/2013/06/03/eclipse-plugin-ansi-in-console/