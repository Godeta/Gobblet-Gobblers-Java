package gobblets.ihm;

//enumeration qui contient les differentes erreurs qui peuvent arriver pendant le jeu
public enum Erreur {
    PASDEPIECEDISPONIBLE,
    PASTAPIECE,
    CASEBLOQUE,
    ARGUMENTINCORECT,
    PASDEPIECEICI,
    PASDETAILLEDISPONIBLE,
    DIAGONALEINCORECTE,
    ORIGINVIDE;

    Erreur() {}
}