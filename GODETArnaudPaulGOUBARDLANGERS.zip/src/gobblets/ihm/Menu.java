package gobblets.ihm;

//enumeration qui contient les differents elements du menu
public enum Menu {
	MENU_AIDE, 
	MENU_APROPOS, 
	MENU_ENREGISTRER, 
	MENU_FICHIER, 
	MENU_LANGUE, 
	MENU_NOUVEAU, 
	MENU_OUVRIR, 
	MENU_MENU,
	MENU_QUITTER;
	
	Menu() {}
}
