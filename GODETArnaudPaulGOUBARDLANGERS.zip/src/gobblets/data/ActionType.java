package gobblets.data;
//les differents types d'actions possibles a chaque tours
public enum ActionType {
    PLACER,
    DEPLACER,
    ENREGISTRER,
    QUITTER;

    ActionType() {};
}