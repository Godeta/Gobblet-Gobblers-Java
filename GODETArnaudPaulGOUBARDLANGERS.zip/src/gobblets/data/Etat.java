package gobblets.data;
//les differents etats possibles de la partie
public enum Etat {
	JEUENCOURS,
    JEUQUITTE,
	JOUEUR1GAGNE,
    JOUEUR2GAGNE,
    ENREGISTRER,
    MATCHNUL;

    Etat() {}
}